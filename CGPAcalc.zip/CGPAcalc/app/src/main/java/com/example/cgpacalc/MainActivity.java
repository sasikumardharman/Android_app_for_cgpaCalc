package com.example.cgpacalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private View v;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void doCALC(View v)
    {
        EditText cr1=(EditText) findViewById(R.id.c1);
        EditText gr1=(EditText) findViewById(R.id.g1);
        EditText cr2=(EditText) findViewById(R.id.c2);
        EditText gr2=(EditText) findViewById(R.id.g2);
        EditText cr3=(EditText) findViewById(R.id.c3);
        EditText gr3=(EditText) findViewById(R.id.g3);
        EditText cr4=(EditText) findViewById(R.id.c4);
        EditText gr4=(EditText) findViewById(R.id.g4);
        EditText cr5=(EditText) findViewById(R.id.c5);
        EditText gr5=(EditText) findViewById(R.id.g5);
        EditText cr6=(EditText) findViewById(R.id.c6);
        EditText gr6=(EditText) findViewById(R.id.g6);
        EditText cr7=(EditText) findViewById(R.id.c7);
        EditText gr7=(EditText) findViewById(R.id.g7);
        EditText cr8=(EditText) findViewById(R.id.c8);
        EditText gr8=(EditText) findViewById(R.id.g8);
        TextView t1=(TextView) findViewById(R.id.result);
        int crr1=Integer.parseInt(cr1.getText().toString());
        int grr1=Integer.parseInt(gr1.getText().toString());
        int crr2=Integer.parseInt(cr2.getText().toString());
        int grr2=Integer.parseInt(gr2.getText().toString());
        int crr3=Integer.parseInt(cr3.getText().toString());
        int grr3=Integer.parseInt(gr3.getText().toString());
        int crr4=Integer.parseInt(cr4.getText().toString());
        int grr4=Integer.parseInt(gr4.getText().toString());
        int crr5=Integer.parseInt(cr5.getText().toString());
        int grr5=Integer.parseInt(gr5.getText().toString());
        int crr6=Integer.parseInt(cr6.getText().toString());
        int grr6=Integer.parseInt(gr6.getText().toString());
        int crr7=Integer.parseInt(cr7.getText().toString());
        int grr7=Integer.parseInt(gr7.getText().toString());
        int crr8=Integer.parseInt(cr8.getText().toString());
        int grr8=Integer.parseInt(gr8.getText().toString());
        int credits=crr1+crr2+crr3+crr3+crr5+crr6+crr7+crr8;
        double cgpa=(((grr1*crr1)+(grr2*crr2)+(grr3*crr3)+(grr4*crr4)+(grr5*crr5)+(grr6*crr6)+(grr7*crr7)+(grr8*crr8))/credits);
        t1.setText(Double.toString(cgpa));
    }
}
